import React, { useState, useEffect } from 'react';
import { Drone2, LayoutGrid, List } from 'lucide-react';
import type { DroneData, ControlInputs } from './types';
import { DroneCard } from './components/DroneCard';
import { DroneControls } from './components/DroneControls';

// Mock data - in a real application, this would come from an API
const mockDrones: DroneData[] = [
  {
    id: "DRN-001",
    name: "Surveyor Alpha",
    status: "active",
    battery: 87,
    altitude: 120,
    speed: 35,
    heading: 45,
    throttle: 0,
    coordinates: { latitude: 51.5074, longitude: -0.1278 },
    lastUpdate: new Date().toISOString()
  },
  {
    id: "DRN-002",
    name: "Inspector Beta",
    status: "idle",
    battery: 92,
    altitude: 0,
    speed: 0,
    heading: 0,
    throttle: 0,
    coordinates: { latitude: 51.5084, longitude: -0.1268 },
    lastUpdate: new Date().toISOString()
  },
  {
    id: "DRN-003",
    name: "Patrol Gamma",
    status: "maintenance",
    battery: 45,
    altitude: 0,
    speed: 0,
    heading: 180,
    throttle: 0,
    coordinates: { latitude: 51.5094, longitude: -0.1288 },
    lastUpdate: new Date().toISOString()
  }
];

function App() {
  const [drones, setDrones] = useState<DroneData[]>(mockDrones);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedDrone, setSelectedDrone] = useState<DroneData | null>(null);

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setDrones(drones.map(drone => ({
        ...drone,
        battery: Math.max(0, drone.battery + (Math.random() > 0.5 ? -1 : 1)),
        altitude: drone.status === 'active' ? drone.altitude + (Math.random() > 0.5 ? -5 : 5) : drone.altitude,
        speed: drone.status === 'active' ? Math.max(0, drone.speed + (Math.random() > 0.5 ? -2 : 2)) : 0,
        heading: drone.status === 'active' ? (drone.heading + (Math.random() > 0.5 ? -5 : 5)) % 360 : drone.heading,
        lastUpdate: new Date().toISOString()
      })));
    }, 5000);

    return () => clearInterval(interval);
  }, [drones]);

  const handleControlChange = (controls: ControlInputs) => {
    if (selectedDrone) {
      setDrones(drones.map(drone => 
        drone.id === selectedDrone.id
          ? {
              ...drone,
              throttle: controls.throttle,
              speed: Math.abs(controls.throttle),
              heading: (drone.heading + controls.yaw) % 360,
              altitude: drone.altitude + (controls.throttle / 10),
              lastUpdate: new Date().toISOString()
            }
          : drone
      ));
    }
  };

  const handleEmergencyStop = () => {
    if (selectedDrone) {
      setDrones(drones.map(drone =>
        drone.id === selectedDrone.id
          ? {
              ...drone,
              status: 'idle',
              speed: 0,
              throttle: 0,
              altitude: 0,
              lastUpdate: new Date().toISOString()
            }
          : drone
      ));
      setSelectedDrone(null);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <Drone2 className="text-blue-600" size={24} />
              <h1 className="text-xl font-semibold text-gray-900">Drone Control Center</h1>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded-md ${viewMode === 'grid' ? 'bg-blue-100 text-blue-600' : 'text-gray-400 hover:text-gray-500'}`}
              >
                <LayoutGrid size={20} />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 rounded-md ${viewMode === 'list' ? 'bg-blue-100 text-blue-600' : 'text-gray-400 hover:text-gray-500'}`}
              >
                <List size={20} />
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <div className={`grid ${viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2' : 'grid-cols-1'} gap-6`}>
              {drones.map(drone => (
                <div
                  key={drone.id}
                  onClick={() => setSelectedDrone(drone)}
                  className={`cursor-pointer transition-all ${selectedDrone?.id === drone.id ? 'ring-2 ring-blue-500 ring-offset-2' : ''}`}
                >
                  <DroneCard drone={drone} />
                </div>
              ))}
            </div>
          </div>
          
          <div className="lg:sticky lg:top-8">
            {selectedDrone ? (
              <DroneControls
                drone={selectedDrone}
                onControlChange={handleControlChange}
                onEmergencyStop={handleEmergencyStop}
              />
            ) : (
              <div className="bg-white rounded-lg shadow-lg p-6 text-center">
                <p className="text-gray-500">Select a drone to control</p>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;