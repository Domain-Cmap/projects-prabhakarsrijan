export interface DroneData {
  id: string;
  name: string;
  status: 'active' | 'idle' | 'maintenance' | 'error';
  battery: number;
  altitude: number;
  speed: number;
  coordinates: {
    latitude: number;
    longitude: number;
  };
  lastUpdate: string;
  heading: number;
  throttle: number;
}

export interface ControlInputs {
  throttle: number;
  yaw: number;
  pitch: number;
  roll: number;
}