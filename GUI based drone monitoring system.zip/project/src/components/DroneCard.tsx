import React from 'react';
import { Battery, Gauge, Wifi, MapPin } from 'lucide-react';
import { StatusBadge } from './StatusBadge';
import type { DroneData } from '../types';

interface DroneCardProps {
  drone: DroneData;
}

export function DroneCard({ drone }: DroneCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">{drone.name}</h3>
          <p className="text-sm text-gray-500">ID: {drone.id}</p>
        </div>
        <StatusBadge status={drone.status} />
      </div>
      
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="flex items-center gap-2">
          <Battery className="text-gray-400" size={20} />
          <div>
            <p className="text-sm text-gray-500">Battery</p>
            <p className="font-medium">{drone.battery}%</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Gauge className="text-gray-400" size={20} />
          <div>
            <p className="text-sm text-gray-500">Speed</p>
            <p className="font-medium">{drone.speed} km/h</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Wifi className="text-gray-400" size={20} />
          <div>
            <p className="text-sm text-gray-500">Altitude</p>
            <p className="font-medium">{drone.altitude}m</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <MapPin className="text-gray-400" size={20} />
          <div>
            <p className="text-sm text-gray-500">Location</p>
            <p className="font-medium text-xs">
              {drone.coordinates.latitude.toFixed(4)}, {drone.coordinates.longitude.toFixed(4)}
            </p>
          </div>
        </div>
      </div>
      
      <p className="text-xs text-gray-400">
        Last updated: {new Date(drone.lastUpdate).toLocaleString()}
      </p>
    </div>
  );
}