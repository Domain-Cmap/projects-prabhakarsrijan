import React, { useState } from 'react';
import { 
  ArrowUp, ArrowDown, RotateCcw, RotateCw, 
  AlertOctagon, Power, Compass, Gauge
} from 'lucide-react';
import type { DroneData, ControlInputs } from '../types';

interface DroneControlsProps {
  drone: DroneData;
  onControlChange: (controls: ControlInputs) => void;
  onEmergencyStop: () => void;
}

export function DroneControls({ drone, onControlChange, onEmergencyStop }: DroneControlsProps) {
  const [controls, setControls] = useState<ControlInputs>({
    throttle: 0,
    yaw: 0,
    pitch: 0,
    roll: 0
  });

  const updateControl = (type: keyof ControlInputs, value: number) => {
    const newControls = { ...controls, [type]: value };
    setControls(newControls);
    onControlChange(newControls);
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-lg font-semibold text-gray-900">Flight Controls</h3>
        <button
          onClick={onEmergencyStop}
          className="bg-red-100 hover:bg-red-200 text-red-700 px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
        >
          <AlertOctagon size={20} />
          Emergency Stop
        </button>
      </div>

      <div className="grid grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="flex flex-col items-center">
            <span className="text-sm text-gray-500 mb-2">Throttle</span>
            <input
              type="range"
              min="-100"
              max="100"
              value={controls.throttle}
              onChange={(e) => updateControl('throttle', parseInt(e.target.value))}
              className="w-full accent-blue-600"
            />
            <div className="flex justify-between w-full mt-1">
              <ArrowDown size={16} className="text-gray-400" />
              <span className="text-sm text-gray-600">{controls.throttle}%</span>
              <ArrowUp size={16} className="text-gray-400" />
            </div>
          </div>

          <div className="flex flex-col items-center">
            <span className="text-sm text-gray-500 mb-2">Yaw</span>
            <input
              type="range"
              min="-100"
              max="100"
              value={controls.yaw}
              onChange={(e) => updateControl('yaw', parseInt(e.target.value))}
              className="w-full accent-blue-600"
            />
            <div className="flex justify-between w-full mt-1">
              <RotateCcw size={16} className="text-gray-400" />
              <span className="text-sm text-gray-600">{controls.yaw}°</span>
              <RotateCw size={16} className="text-gray-400" />
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-2">
              <Compass className="text-blue-600" size={20} />
              <span className="text-sm text-gray-600">Heading: {drone.heading}°</span>
            </div>
            <div className="flex items-center gap-2">
              <Gauge className="text-blue-600" size={20} />
              <span className="text-sm text-gray-600">Speed: {drone.speed} km/h</span>
            </div>
          </div>

          <div className="relative aspect-square">
            <div className="absolute inset-0 bg-gray-100 rounded-full">
              <div 
                className="absolute w-4 h-4 bg-blue-600 rounded-full transform -translate-x-1/2 -translate-y-1/2"
                style={{
                  left: `${50 + (controls.roll / 2)}%`,
                  top: `${50 + (controls.pitch / 2)}%`
                }}
              />
            </div>
            <div 
              className="absolute inset-0 cursor-move"
              onMouseMove={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                const x = ((e.clientX - rect.left) / rect.width) * 200 - 100;
                const y = ((e.clientY - rect.top) / rect.height) * 200 - 100;
                updateControl('roll', Math.max(-100, Math.min(100, x)));
                updateControl('pitch', Math.max(-100, Math.min(100, y)));
              }}
            />
          </div>
        </div>
      </div>

      <div className="mt-6 p-4 bg-gray-50 rounded-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Power className={`${drone.status === 'active' ? 'text-green-600' : 'text-gray-400'}`} size={20} />
            <span className="text-sm text-gray-600">Control Status: {drone.status}</span>
          </div>
          <span className="text-xs text-gray-400">Last Update: {new Date(drone.lastUpdate).toLocaleString()}</span>
        </div>
      </div>
    </div>
  );
}